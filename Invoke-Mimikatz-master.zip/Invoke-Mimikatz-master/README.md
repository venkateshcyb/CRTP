# Invoke-Mimikatz
Reflectively loads Mimikatz 2.2 in memory using PowerShell. Can be used to dump credentials without writing anything to disk. Can be used for any functionality provided with Mimikatz.
This repository intent is only to try to keep updating the Powershell version of Mimikatz to its latest release
